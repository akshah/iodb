<?php

session_start();

require_once 'vendor/autoload.php';
require_once 'classes/DB.php';
require_once 'classes/GoogleAuth.php';

