<?php
/************************************************
 ATTENTION: Fill in these values! Make sure
the redirect URI is to this page, e.g:
http://localhost:8080/user-example.php
************************************************/
$client_id = '409139447429-na3m0dohs7p6j4rqfaum4sql8hc9ng70.apps.googleusercontent.com';
$client_secret = 'yQgclubQmz5SgrC1xw0FjHuY';
$redirect_uri = 'postmessage';
